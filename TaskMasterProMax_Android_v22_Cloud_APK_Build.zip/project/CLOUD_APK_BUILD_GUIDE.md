# TaskMaster Pro Max v22 — Mobile APK Build

This package is prepared for a cloud Android build. No Android Studio is required on the user's phone.

## What the cloud workflow does
1. Installs Android SDK 35 and Java 17.
2. Runs the existing release/static QA gates.
3. Builds an installable debug APK.
4. Verifies the APK is non-empty.
5. Produces a SHA-256 checksum.
6. Uploads the APK as a downloadable GitHub Actions artifact.

## Important
This project is not itself an APK. A cloud CI service must execute `.github/workflows/android-apk-cloud-build.yml`.

For a phone-only workflow, the practical route is to upload this project to a GitHub repository from a browser, then open Actions → "TaskMaster Pro Max - Cloud APK Build" → Run workflow. After it finishes, download the APK artifact and install it on Android.

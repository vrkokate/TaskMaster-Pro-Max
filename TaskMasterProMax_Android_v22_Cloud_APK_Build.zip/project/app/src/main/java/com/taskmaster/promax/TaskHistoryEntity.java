package com.taskmaster.promax;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "task_history", indices = { @androidx.room.Index(value = {"taskId", "at"}) })
public class TaskHistoryEntity {
    @PrimaryKey(autoGenerate = true) public long id;
    public String taskId;
    public String action;
    public long at;
    public long fromDueAt;
    public long toDueAt;
    public String note;
    public TaskHistoryEntity(String taskId,String action,long at,long fromDueAt,long toDueAt,String note){
        this.taskId=taskId;this.action=action;this.at=at;this.fromDueAt=fromDueAt;this.toDueAt=toDueAt;this.note=note;
    }
}

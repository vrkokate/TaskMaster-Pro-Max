package com.taskmaster.promax;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {

    private void restoreRecurring(Context context, AlarmManager am) {
        ReminderDatabase db = androidx.room.Room.databaseBuilder(
            context.getApplicationContext(), ReminderDatabase.class, "taskmaster.db")
            .addMigrations(ReminderDatabase.MIGRATION_3_4).build();
        long now = System.currentTimeMillis();
        for (RecurringTaskEntity e : db.recurringTaskDao().enabled()) {
            long next = e.firstDueAt;
            while (next <= now) next = nextOccurrence(next, e.recurrence);
            Intent ri = new Intent(context, ReminderReceiver.class)
                .putExtra("taskId", e.id).putExtra("title", e.title);
            PendingIntent pi = PendingIntent.getBroadcast(context, e.id.hashCode() & 0x7fffffff,
                ri, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,next,pi);
        }
        db.close();
    }

    private long nextOccurrence(long at,String recurrence) {
        java.util.Calendar c=java.util.Calendar.getInstance();
        c.setTimeInMillis(at);
        if ("WEEKLY".equals(recurrence)) c.add(java.util.Calendar.DAY_OF_YEAR,7);
        else if ("MONTHLY".equals(recurrence)) c.add(java.util.Calendar.MONTH,1);
        else c.add(java.util.Calendar.DAY_OF_YEAR,1);
        return c.getTimeInMillis();
    }

    private void restoreRoom(Context context, AlarmManager am) {
        ReminderDatabase db = androidx.room.Room.databaseBuilder(
            context.getApplicationContext(), ReminderDatabase.class, "taskmaster.db").build();
        for (ReminderEntity e : db.reminderDao().future(System.currentTimeMillis())) {
            Intent ri = new Intent(context, ReminderReceiver.class)
                .putExtra("taskId", e.taskId).putExtra("title", e.title);
            PendingIntent pi = PendingIntent.getBroadcast(context, e.taskId.hashCode() & 0x7fffffff,
                ri, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.triggerAt, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, e.triggerAt, pi);
        }
        db.close();
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) &&
            !Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) return;

        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null || !am.canScheduleExactAlarms()) return;
        }

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try { restoreRoom(context, am); restoreRecurring(context, am); } catch (Exception ignored) {}

        Map<String, ?> all = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).getAll();
        for (Map.Entry<String, ?> e : all.entrySet()) {
            String taskId = e.getKey();
            String raw = String.valueOf(e.getValue());
            int split = raw.lastIndexOf('\n');
            if (split < 0) continue;
            String title = raw.substring(0, split);
            long at;
            try { at = Long.parseLong(raw.substring(split + 1)); }
            catch (Exception ex) { continue; }
            if (at <= System.currentTimeMillis()) continue;

            Intent ri = new Intent(context, ReminderReceiver.class)
                .putExtra("taskId", taskId).putExtra("title", title);
            PendingIntent pi = PendingIntent.getBroadcast(
                context, taskId.hashCode() & 0x7fffffff, ri,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}

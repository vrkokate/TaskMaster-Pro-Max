package com.taskmaster.promax;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tasks", indices = { @androidx.room.Index(value = {"dueAt"}), @androidx.room.Index(value = {"status"}) })
public class TaskEntity {
    @PrimaryKey public String id;
    public String title;
    public String notes;
    public String status;
    public String priority;
    public String category;
    public long dueAt;
    public long createdAt;
    public long completedAt;
    public int postponeCount;
    public TaskEntity(String id, String title, String notes, String status, String priority,
                      String category, long dueAt, long createdAt, long completedAt, int postponeCount) {
        this.id=id; this.title=title; this.notes=notes; this.status=status; this.priority=priority;
        this.category=category; this.dueAt=dueAt; this.createdAt=createdAt;
        this.completedAt=completedAt; this.postponeCount=postponeCount;
    }
}

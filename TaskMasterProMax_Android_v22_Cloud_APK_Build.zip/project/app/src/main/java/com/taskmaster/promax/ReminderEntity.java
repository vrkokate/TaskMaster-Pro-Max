package com.taskmaster.promax;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "reminders", indices = { @androidx.room.Index(value = {"triggerAt"}) })
public class ReminderEntity {
    @PrimaryKey public String taskId;
    public String title;
    public long triggerAt;
    public ReminderEntity(String taskId, String title, long triggerAt) {
        this.taskId = taskId; this.title = title; this.triggerAt = triggerAt;
    }
}

package com.taskmaster.promax;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities={ReminderEntity.class,TaskEntity.class,TaskHistoryEntity.class,RecurringTaskEntity.class},
          version=4,exportSchema=false)
public abstract class ReminderDatabase extends RoomDatabase {
    public abstract ReminderDao reminderDao();
    public abstract TaskDao taskDao();
    public abstract RecurringTaskDao recurringTaskDao();

    /** Safe schema-only migration: preserves every existing record.
     * The index declarations in each @Entity intentionally mirror these exact
     * indexes so Room schema validation remains stable after upgrade. */
    public static final Migration MIGRATION_3_4 = new Migration(3,4) {
        @Override public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("CREATE INDEX IF NOT EXISTS index_tasks_dueAt ON tasks(dueAt)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_tasks_status ON tasks(status)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_task_history_taskId_at ON task_history(taskId, at)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_reminders_triggerAt ON reminders(triggerAt)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_recurring_enabled_firstDueAt ON recurring_tasks(enabled, firstDueAt)");
        }
    };
}

package com.taskmaster.promax;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        String taskId = intent.getStringExtra("taskId");
        if (title == null || title.trim().isEmpty()) title = "Task Reminder";

        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("taskId", taskId);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pi = PendingIntent.getActivity(
            context, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(
            context, MainActivity.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("TaskMaster Pro Max")
            .setContentText(title)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pi);

        NotificationManager nm = (NotificationManager)
            context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null)
            nm.notify((taskId == null ? title : taskId).hashCode(), b.build());

        
        // Recurring tasks: schedule the next occurrence after this notification.
        if (taskId != null) {
            new Thread(() -> {
                try {
                    ReminderDatabase db = androidx.room.Room.databaseBuilder(
                        context.getApplicationContext(), ReminderDatabase.class, "taskmaster.db")
                        .addMigrations(ReminderDatabase.MIGRATION_3_4).build();
                    RecurringTaskEntity rt = null;
                    for (RecurringTaskEntity x : db.recurringTaskDao().enabled())
                        if (x.id.equals(taskId)) { rt=x; break; }
                    if (rt != null) {
                        java.util.Calendar c=java.util.Calendar.getInstance();
                        c.setTimeInMillis(System.currentTimeMillis());
                        if ("WEEKLY".equals(rt.recurrence)) c.add(java.util.Calendar.DAY_OF_YEAR,7);
                        else if ("MONTHLY".equals(rt.recurrence)) c.add(java.util.Calendar.MONTH,1);
                        else c.add(java.util.Calendar.DAY_OF_YEAR,1);
                        long next=c.getTimeInMillis();
                        Intent ni=new Intent(context,ReminderReceiver.class)
                            .putExtra("taskId",rt.id).putExtra("title",rt.title);
                        PendingIntent npi=PendingIntent.getBroadcast(context,rt.id.hashCode()&0x7fffffff,
                            ni,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                        android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
                        if(am!=null){
                            if(android.os.Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,next,npi);
                            else am.setExact(android.app.AlarmManager.RTC_WAKEUP,next,npi);
                        }
                    }
                    db.close();
                } catch(Exception ignored) {}
            }).start();
        }

// One-shot alarm; remove stored entry so reboot restore only keeps future alarms.
        if (taskId != null) {
            try {
                ReminderDatabase db = androidx.room.Room.databaseBuilder(
                    context.getApplicationContext(), ReminderDatabase.class, "taskmaster.db")
                    .addMigrations(ReminderDatabase.MIGRATION_3_4).build();
                db.taskDao().addHistory(new TaskHistoryEntity(taskId,"REMINDER_FIRED",
                    System.currentTimeMillis(),0,0,"Reminder notification shown"));
                db.close();
            } catch(Exception ignored) {}
            context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().remove(taskId).apply();
            new Thread(() -> {
                ReminderDatabase db = androidx.room.Room.databaseBuilder(
                    context.getApplicationContext(), ReminderDatabase.class, "taskmaster.db").build();
                db.reminderDao().delete(taskId);
                db.close();
            }).start();
    }
}

}
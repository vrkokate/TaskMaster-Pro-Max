package com.taskmaster.promax;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="recurring_tasks", indices = { @androidx.room.Index(value = {"enabled", "firstDueAt"}) })
public class RecurringTaskEntity {
    @PrimaryKey public String id;
    public String title;
    public String notes;
    public String priority;
    public String category;
    public long firstDueAt;
    public String recurrence; // DAILY, WEEKLY, MONTHLY
    public boolean enabled;
    public RecurringTaskEntity(String id,String title,String notes,String priority,String category,
                               long firstDueAt,String recurrence,boolean enabled){
        this.id=id;this.title=title;this.notes=notes;this.priority=priority;this.category=category;
        this.firstDueAt=firstDueAt;this.recurrence=recurrence;this.enabled=enabled;
    }
}

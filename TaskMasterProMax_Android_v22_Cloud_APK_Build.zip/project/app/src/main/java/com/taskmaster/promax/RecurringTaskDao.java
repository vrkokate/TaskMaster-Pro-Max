package com.taskmaster.promax;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface RecurringTaskDao {
    @Insert(onConflict=OnConflictStrategy.REPLACE) void upsert(RecurringTaskEntity t);
    @Query("SELECT * FROM recurring_tasks WHERE enabled=1") List<RecurringTaskEntity> enabled();
    @Query("UPDATE recurring_tasks SET enabled=:enabled WHERE id=:id") void setEnabled(String id,boolean enabled);
    @Query("DELETE FROM recurring_tasks WHERE id=:id") void delete(String id);
}

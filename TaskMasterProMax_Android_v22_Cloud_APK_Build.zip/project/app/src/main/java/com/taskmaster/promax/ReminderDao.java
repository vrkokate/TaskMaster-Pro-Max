package com.taskmaster.promax;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface ReminderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) void upsert(ReminderEntity item);
    @Query("DELETE FROM reminders WHERE taskId=:id") void delete(String id);
    @Query("SELECT * FROM reminders WHERE triggerAt > :now ORDER BY triggerAt ASC") List<ReminderEntity> future(long now);
}

package com.taskmaster.promax;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface TaskDao {
    @Insert(onConflict=OnConflictStrategy.REPLACE) void upsert(TaskEntity t);
    @Query("SELECT * FROM tasks WHERE id=:id LIMIT 1") TaskEntity get(String id);
    @Query("SELECT * FROM tasks ORDER BY dueAt ASC, createdAt DESC") List<TaskEntity> all();
    @Query("SELECT * FROM tasks WHERE dueAt >= :from AND dueAt < :to ORDER BY dueAt ASC")
    List<TaskEntity> between(long from,long to);
    @Query("SELECT COUNT(*) FROM tasks") int countAll();
    @Query("SELECT COUNT(*) FROM tasks WHERE status='COMPLETED'") int countCompleted();
    @Query("SELECT COUNT(*) FROM tasks WHERE status!='COMPLETED'") int countPending();
    @Query("SELECT COUNT(*) FROM tasks WHERE status!='COMPLETED' AND dueAt < :now") int countOverdue();
    @Query("SELECT * FROM tasks WHERE status != 'COMPLETED' ORDER BY dueAt ASC") List<TaskEntity> active();
    @Query("UPDATE tasks SET status=:status, completedAt=:completedAt WHERE id=:id") void setStatus(String id,String status,long completedAt);
    @Query("UPDATE tasks SET dueAt=:dueAt, postponeCount=postponeCount+1 WHERE id=:id") void reschedule(String id,long dueAt);
    @Query("DELETE FROM tasks WHERE id=:id") void delete(String id);
    @Query("DELETE FROM tasks") void deleteAll();
    @Insert void addHistory(TaskHistoryEntity h);
    @Query("SELECT * FROM task_history WHERE taskId=:taskId ORDER BY at DESC") List<TaskHistoryEntity> history(String taskId);
}

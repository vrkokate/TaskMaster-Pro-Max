package com.taskmaster.promax;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/*
 * Hook for persistent rescheduling after reboot/update.
 * The HTML task store can be migrated to SharedPreferences/Room in the
 * next native-data phase. This receiver intentionally performs no unsafe
 * parsing of WebView storage.
 */
public class ReminderRescheduler extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // Native persistence/schedule migration point.
    }
}

package com.taskmaster.promax;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    public static final String CHANNEL_ID = "task_reminders";
    public static final String PREFS = "taskmaster_reminders";
    private static final int NOTIFICATION_REQUEST = 1001;
    private WebView web;
    private static ReminderDatabase db;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        setContentView(R.layout.activity_main);

        db = androidx.room.Room.databaseBuilder(getApplicationContext(), ReminderDatabase.class, "taskmaster.db").addMigrations(ReminderDatabase.MIGRATION_3_4).build();
        web = findViewById(R.id.web);
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.addJavascriptInterface(new Android(this), "Android");
        web.addJavascriptInterface(new Android(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");

        requestNotificationPermission();
        handleReminderIntent(getIntent());
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("Android"); web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleReminderIntent(intent);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL_ID, "Task Reminders", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("TaskMaster Pro Max reminders");
            c.enableVibration(true);
            c.setVibrationPattern(new long[]{0,400,250,400,250,700});
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(c);
        }
    }

    private void handleReminderIntent(Intent intent) {
        if (intent != null && intent.hasExtra("taskId") && web != null) {
            String taskId = intent.getStringExtra("taskId");
            String q = MainActivity.quote(taskId == null ? "" : taskId);
            web.postDelayed(() -> web.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('openTaskFromReminder',{detail:{id:" + q + "}}));",
                null), 700);
        }
    }

    public static String quote(String s) {
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"")
            .replace("\n","\\n").replace("\r","\\r") + "\"";
    }

    public static class Android {
        private final Context context;
        Android(Context c) { context = c.getApplicationContext(); }

        @JavascriptInterface public boolean notificationsEnabled() {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        }

        @JavascriptInterface public void openNotificationSettings() {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        }

        @JavascriptInterface public void saveTask(String id,String title,String notes,String status,String priority,String category,long dueAt,long createdAt) {
            new Thread(() -> {
                TaskEntity old = db.taskDao().get(id);
                long completedAt = old == null ? 0 : old.completedAt;
                int postponeCount = old == null ? 0 : old.postponeCount;
                db.taskDao().upsert(new TaskEntity(id,title,notes,status,priority,category,dueAt,createdAt,completedAt,postponeCount));
            }).start();
        }

        @JavascriptInterface public void setTaskStatus(String id,String status) {
            new Thread(() -> {
                long completedAt = "COMPLETED".equals(status) ? System.currentTimeMillis() : 0;
                db.taskDao().setStatus(id,status,completedAt);
                db.taskDao().addHistory(new TaskHistoryEntity(id,status,System.currentTimeMillis(),0,0,"Status changed"));
            }).start();
        }

        @JavascriptInterface public void completeTask(String id) {
            new Thread(() -> {
                db.taskDao().setStatus(id,"COMPLETED",System.currentTimeMillis());
                db.taskDao().addHistory(new TaskHistoryEntity(id,"COMPLETED",System.currentTimeMillis(),0,0,"Task completed"));
            }).start();
            cancelReminder(id);
        }

        @JavascriptInterface public void rescheduleTask(String id,long fromDueAt,long toDueAt,String note) {
            new Thread(() -> {
                db.taskDao().reschedule(id,toDueAt);
                db.taskDao().addHistory(new TaskHistoryEntity(id,"RESCHEDULED",System.currentTimeMillis(),fromDueAt,toDueAt,note));
            }).start();
        }

        @JavascriptInterface public void clearNativeTasks() {
            new Thread(() -> {
                db.taskDao().deleteAll();
            }).start();
        }

        @JavascriptInterface public String getNativeDatabaseInfoJson() {
            final java.util.concurrent.atomic.AtomicReference<String> out = new java.util.concurrent.atomic.AtomicReference<>("{\"ready\":false,\"tasks\":0}");
            Thread t = new Thread(() -> {
                try { out.set("{\"ready\":true,\"tasks\":" + db.taskDao().countAll() + "}"); } catch(Exception ignored) {}
            });
            t.start(); try { t.join(700); } catch(Exception ignored) {}
            return out.get();
        }

        @JavascriptInterface public void deleteTaskNative(String id) {
            new Thread(() -> db.taskDao().delete(id)).start();
            cancelReminder(id);
        }

        @JavascriptInterface public String getNativeTaskHistoryJson(String id) {
            final java.util.concurrent.atomic.AtomicReference<String> out = new java.util.concurrent.atomic.AtomicReference<>("[]");
            Thread t = new Thread(() -> {
                java.util.List<TaskHistoryEntity> hs = db.taskDao().history(id);
                StringBuilder s = new StringBuilder("[");
                for(int i=0;i<hs.size();i++){
                    TaskHistoryEntity h=hs.get(i);
                    if(i>0)s.append(",");
                    s.append("{\"action\":").append(MainActivity.quote(h.action))
                     .append(",\"at\":").append(h.at)
                     .append(",\"fromDueAt\":").append(h.fromDueAt)
                     .append(",\"toDueAt\":").append(h.toDueAt)
                     .append(",\"note\":").append(MainActivity.quote(h.note==null?"":h.note)).append("}");
                }
                s.append("]");
                out.set(s.toString());
            });
            t.start();
            try { t.join(800); } catch(Exception ignored){}
            return out.get();
        }

        @JavascriptInterface public void saveRecurringTask(String id,String title,String notes,String priority,
                String category,long firstDueAt,String recurrence) {
            new Thread(() -> db.recurringTaskDao().upsert(
                new RecurringTaskEntity(id,title,notes,priority,category,firstDueAt,recurrence,true)
            )).start();
        }

        @JavascriptInterface public void setRecurringEnabled(String id,boolean enabled) {
            new Thread(() -> db.recurringTaskDao().setEnabled(id,enabled)).start();
        }

        @JavascriptInterface public void deleteRecurringTask(String id) {
            new Thread(() -> db.recurringTaskDao().delete(id)).start();
        }

        @JavascriptInterface public void smartPostpone(String id,long fromDueAt,long toDueAt,String reason) {
            new Thread(() -> {
                db.taskDao().reschedule(id,toDueAt);
                db.taskDao().addHistory(new TaskHistoryEntity(id,"SMART_POSTPONE",
                    System.currentTimeMillis(),fromDueAt,toDueAt,reason==null?"":reason));
            }).start();
            cancelReminder(id);
        }

        @JavascriptInterface public String getDashboardStatsJson() {
            final java.util.concurrent.atomic.AtomicReference<String> out =
                new java.util.concurrent.atomic.AtomicReference<>("{\"total\":0,\"completed\":0,\"pending\":0,\"overdue\":0}");
            Thread t=new Thread(() -> {
                try {
                    int total=db.taskDao().countAll(), completed=db.taskDao().countCompleted(),
                        pending=db.taskDao().countPending(), overdue=db.taskDao().countOverdue(System.currentTimeMillis());
                    out.set("{\"total\":"+total+",\"completed\":"+completed+",\"pending\":"+pending+",\"overdue\":"+overdue+"}");
                } catch(Exception ignored) {}
            });
            t.start(); try{t.join(700);}catch(Exception ignored){}
            return out.get();
        }

        @JavascriptInterface public String getNativeTasksJson() {
            final java.util.concurrent.atomic.AtomicReference<String> out =
                new java.util.concurrent.atomic.AtomicReference<>("[]");
            Thread t=new Thread(() -> {
                try {
                    java.util.List<TaskEntity> ts=db.taskDao().all();
                    StringBuilder s=new StringBuilder("[");
                    for(int i=0;i<ts.size();i++){
                        TaskEntity x=ts.get(i); if(i>0)s.append(",");
                        s.append("{\"id\":").append(MainActivity.quote(x.id))
                         .append(",\"title\":").append(MainActivity.quote(x.title==null?"":x.title))
                         .append(",\"notes\":").append(MainActivity.quote(x.notes==null?"":x.notes))
                         .append(",\"status\":").append(MainActivity.quote(x.status==null?"":x.status))
                         .append(",\"priority\":").append(MainActivity.quote(x.priority==null?"":x.priority))
                         .append(",\"category\":").append(MainActivity.quote(x.category==null?"":x.category))
                         .append(",\"dueAt\":").append(x.dueAt)
                         .append(",\"createdAt\":").append(x.createdAt)
                         .append(",\"completedAt\":").append(x.completedAt)
                         .append(",\"postponeCount\":").append(x.postponeCount).append("}");
                    }
                    s.append("]"); out.set(s.toString());
                } catch(Exception ignored) {}
            });
            t.start(); try{t.join(900);}catch(Exception ignored){}
            return out.get();
        }

        @JavascriptInterface public boolean nativeDatabaseReady() { return db != null && !db.isOpen() ? false : db != null; }

        @JavascriptInterface public String nativeHealthJson() {
            final java.util.concurrent.atomic.AtomicReference<String> out = new java.util.concurrent.atomic.AtomicReference<>("{\"ready\":false}");
            Thread t = new Thread(() -> {
                try { int tasks=db.taskDao().countAll(); out.set("{\"ready\":true,\"tasks\":"+tasks+",\"database\":\"Room\"}"); } catch(Exception ignored) {}
            });
            t.start(); try { t.join(700); } catch(Exception ignored) {}
            return out.get();
        }

        @JavascriptInterface public boolean exactAlarmAllowed() {
            if (Build.VERSION.SDK_INT < 31) return true;
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }

        @JavascriptInterface public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= 31) {
                Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + context.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        }

        @JavascriptInterface public boolean scheduleReminder(String taskId, String title, long triggerAtMillis) {
            if (taskId == null || taskId.trim().isEmpty() || triggerAtMillis <= System.currentTimeMillis())
                return false;

            if (Build.VERSION.SDK_INT >= 31 && !exactAlarmAllowed()) return false;

            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return false;

            Intent i = new Intent(context, ReminderReceiver.class)
                .putExtra("taskId", taskId)
                .putExtra("title", title == null ? "Task Reminder" : title);

            PendingIntent pi = PendingIntent.getBroadcast(
                context, stableRequestCode(taskId), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            else
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(taskId, (title == null ? "Task Reminder" : title) + "\n" + triggerAtMillis)
                .apply();
            new Thread(() -> db.reminderDao().upsert(
                new ReminderEntity(taskId, title == null ? "Task Reminder" : title, triggerAtMillis)
            )).start();
            return true;
        }

        @JavascriptInterface public void cancelReminder(String taskId) {
            if (taskId == null || taskId.trim().isEmpty()) return;
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                Intent i = new Intent(context, ReminderReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(
                    context, stableRequestCode(taskId), i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.cancel(pi);
                pi.cancel();
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(taskId).apply();
            new Thread(() -> db.reminderDao().delete(taskId)).start();
        }

        private static int stableRequestCode(String id) {
            return id.hashCode() & 0x7fffffff;
        }
    }
}

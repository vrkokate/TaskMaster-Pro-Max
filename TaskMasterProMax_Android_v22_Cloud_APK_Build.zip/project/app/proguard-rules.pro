# TaskMaster Pro Max release rules
-keep class com.taskmaster.promax.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

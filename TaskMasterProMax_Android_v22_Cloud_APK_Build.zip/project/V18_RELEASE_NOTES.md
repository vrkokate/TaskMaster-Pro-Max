# TaskMaster Pro Max v18 — Reproducible Release Verification

Version: 1.0.7 (18)

- Promotes v17 to the next release candidate.
- Adds source manifest generation and verification.
- CI now runs preflight before Gradle build.
- Release artifact label updated to v1.0.7.
- No existing UI feature was intentionally removed or redesigned.

## Local verification
Run `python3 tools/release_manifest.py`, then `python3 tools/verify_release_source.py`.
Build with the existing release workflow or Android/Gradle toolchain.

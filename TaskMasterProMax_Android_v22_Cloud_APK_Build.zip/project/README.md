# TaskMaster Pro Max — v14 Production Build Preparation

Version: **1.0.3** / **versionCode 14**

v14 is the production-build preparation stage. It keeps the v13 application/database architecture and adds a corrected preflight validator, real-device acceptance checklist, release hygiene files, and a CI workflow that can build APK/AAB on a hosted Android environment.

This package is source code; no signed APK is claimed to have been built here.

# TaskMaster Pro Max v14 — Build & Real-Device QA

## Build
1. Open the project in Android Studio.
2. Let Android Studio install/resolve Android SDK 35 and Gradle dependencies.
3. Run `python tools/preflight.py`.
4. Build **Build > Generate App Bundles or APKs > Generate APKs** for a debug smoke test.
5. For production, configure a release keystore; never commit the keystore or passwords.
6. Build a signed AAB/APK.

## Real-device acceptance checklist
- [ ] Fresh install launches to Home without crash.
- [ ] Create task and close/reopen app; task remains.
- [ ] Edit task; verify updated values persist.
- [ ] Complete one task; other tasks remain unchanged.
- [ ] Reschedule task; original date/history and postpone count remain.
- [ ] Create Daily/Weekly/Monthly recurring task and verify next occurrence.
- [ ] Schedule a 1–2 minute reminder; verify sound, vibration and notification.
- [ ] Tap notification; verify the correct task opens.
- [ ] Reboot device; verify future reminders are restored.
- [ ] Deny exact-alarm access; verify app handles the unavailable state gracefully.
- [ ] Deny notification permission; verify task creation still works.
- [ ] Calendar date navigation and daily/weekly/monthly views.
- [ ] Search and filters.
- [ ] Dashboard counts match task list.
- [ ] Reports/analytics render correctly.
- [ ] Backup JSON and restore on the same device.
- [ ] CSV export opens correctly.
- [ ] Clear-all data removes UI and native task data.
- [ ] Test dark/light settings if enabled.

## Release evidence
Record Android version, device model, build number, APK/AAB SHA-256, and screenshots for any failed case.

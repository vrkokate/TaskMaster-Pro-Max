# TaskMaster Pro Max v15 — Final Build Handoff

Version: 1.0.4 (code 15)

## Completed
- Production source carried forward from v14.
- Release metadata advanced to 1.0.4 / code 15.
- Static release audit added.
- APK/AAB build scripts retained.
- Final device QA documentation retained.

## Build gate
This environment does not provide a usable Android SDK/Gradle toolchain, so APK/AAB compilation is intentionally **not claimed**.

## Android Studio
1. Open this project folder.
2. Let Gradle sync complete.
3. Run `tools/preflight.py` (or `python tools/release_audit.py`).
4. Build `assembleDebug` for device smoke testing.
5. Build signed `assembleRelease` and `bundleRelease` only after configuring a private release keystore.
6. Run the device QA checklist before distribution.

## Signing
Never place a real keystore, passwords, or signing secrets in this ZIP or source control.

# TaskMaster Pro Max v13 — Release Checklist

## Completed in this package
- [x] Version 1.0.2 / code 13
- [x] Room schema upgraded 3 -> 4 with non-destructive migration
- [x] Database indexes for due date, status, history, reminders and recurring tasks
- [x] Removed destructive migration fallback
- [x] WebView lifecycle cleanup in MainActivity
- [x] Release build helper scripts
- [x] GitHub Actions release build workflow
- [x] Existing backup/restore rules retained
- [x] Existing reminder, recurring, calendar, search and reports features retained

## Required on a real Android device
- [ ] Install release APK
- [ ] Add/edit/complete/reschedule task
- [ ] Verify notification + vibration + sound
- [ ] Verify exact-alarm permission path on Android 12+
- [ ] Reboot device and verify reminder restoration
- [ ] Verify recurring task generation
- [ ] Backup -> clear -> restore and verify data
- [ ] Test portrait UI on at least two screen sizes
- [ ] Generate signed AAB/APK with production keystore

#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
print('Running final static build gate...')
r=subprocess.run([sys.executable,str(root/'qa_check.py')],cwd=root)
if r.returncode: sys.exit(r.returncode)
print('FINAL BUILD GATE: PASS')

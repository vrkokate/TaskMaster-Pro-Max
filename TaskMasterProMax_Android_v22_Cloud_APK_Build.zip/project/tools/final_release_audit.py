from pathlib import Path
import re, zipfile, hashlib, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def ok(name, cond, detail=''):
    checks.append((name, bool(cond), detail))
g=(root/'app/build.gradle').read_text(encoding='utf-8')
m=re.search(r'versionCode\s+(\d+)',g); vn=re.search(r'versionName\s+"([^"]+)"',g)
code=m.group(1) if m else ''; name=vn.group(1) if vn else ''
ok('release version parsed', bool(code and name))
ok('compileSdk 35', 'compileSdk 35' in g)
ok('targetSdk 35', 'targetSdk 35' in g)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
for x in ['POST_NOTIFICATIONS','RECEIVE_BOOT_COMPLETED','SCHEDULE_EXACT_ALARM','BOOT_COMPLETED','MY_PACKAGE_REPLACED']:
    ok(f'manifest {x}', x in manifest)
db=(root/'app/src/main/java/com/taskmaster/promax/ReminderDatabase.java').read_text(encoding='utf-8')
ok('Room version 4', re.search(r'version\s*=\s*4',db) is not None)
ok('Migration 3_4', 'MIGRATION_3_4' in db)
ok('No destructive migration', 'fallbackToDestructiveMigration' not in db)
main=(root/'app/src/main/java/com/taskmaster/promax/MainActivity.java').read_text(encoding='utf-8')
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
ok('Reminder deep link', 'openTaskFromReminder' in main and 'openTaskFromReminder' in html)
ok('Native task save bridge', 'saveTask' in main)
ok('HTML asset present', len(html)>1000)
ok('CI release workflow', (root/'.github/workflows/android-release.yml').exists())
ok('CI verification workflow', (root/'.github/workflows/android-release.yml').read_text().count('sha256sum')>0)
for p in (root/'app/src/main/java/com/taskmaster/promax').glob('*.java'):
    s=p.read_text(encoding='utf-8'); ok(f'balanced braces {p.name}', s.count('{')==s.count('}'))
passed=sum(c for _,c,_ in checks)
report=root/'FINAL_RELEASE_AUDIT.txt'
report.write_text('\n'.join([f'TaskMaster Pro Max v{name} / code {code}','',*(('PASS' if c else 'FAIL')+' | '+n+(' | '+d if d else '') for n,c,d in checks), '',f'PASS_COUNT={passed}/{len(checks)}', 'BUILD_STATUS=NOT_EXECUTED_IN_THIS_ENVIRONMENT', 'BUILD_NOTE=Use the CI workflow or Android Studio with a configured Android SDK/Gradle environment to produce APK/AAB.']),encoding='utf-8')
print(f'FINAL RELEASE AUDIT: {passed}/{len(checks)} PASS')
if passed != len(checks): sys.exit(1)

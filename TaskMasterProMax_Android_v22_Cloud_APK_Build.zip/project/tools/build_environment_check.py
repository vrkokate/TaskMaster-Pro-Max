#!/usr/bin/env python3
import shutil, os, json
print(json.dumps({
  "gradle": shutil.which("gradle"),
  "java": shutil.which("java"),
  "adb": shutil.which("adb"),
  "ANDROID_HOME": os.environ.get("ANDROID_HOME"),
  "ANDROID_SDK_ROOT": os.environ.get("ANDROID_SDK_ROOT"),
}, indent=2))

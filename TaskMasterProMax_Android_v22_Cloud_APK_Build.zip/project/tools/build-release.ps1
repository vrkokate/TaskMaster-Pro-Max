$ErrorActionPreference = "Stop"
Write-Host "TaskMaster Pro Max v13 - Release build"
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
  Write-Host "Gradle command not found. Open the project in Android Studio or add Gradle wrapper first."
  exit 2
}
gradle :app:assembleRelease :app:bundleRelease

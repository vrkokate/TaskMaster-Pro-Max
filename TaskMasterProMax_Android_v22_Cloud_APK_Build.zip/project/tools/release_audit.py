#!/usr/bin/env python3
from pathlib import Path
import re, shutil, zipfile, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def ok(name, cond, detail=''):
    checks.append((name, bool(cond), detail))
app=ROOT/'app'/'build.gradle'
manifest=ROOT/'app'/'src'/'main'/'AndroidManifest.xml'
html=ROOT/'app'/'src'/'main'/'assets'/'index.html'
ok('Project settings', (ROOT/'settings.gradle').exists() and (ROOT/'build.gradle').exists())
text=app.read_text() if app.exists() else ''
ok('Version 1.0.4 / code 15', 'versionCode 16' in text and 'versionName "1.0.5"' in text)
ok('compileSdk 35', 'compileSdk 35' in text)
ok('targetSdk 35', 'targetSdk 35' in text)
ok('Manifest present', manifest.exists())
ok('Web app asset present', html.exists() and html.stat().st_size > 10000)
if manifest.exists():
    m=manifest.read_text()
    ok('Notifications permission', 'POST_NOTIFICATIONS' in m)
    ok('Boot receiver permission', 'RECEIVE_BOOT_COMPLETED' in m)
    ok('Exact alarm permission', 'SCHEDULE_EXACT_ALARM' in m)
if html.exists():
    h=html.read_text(errors='ignore')
    for token in ['Calendar','Reports','Recurring','Backup','Restore','Reschedule','Reminder']:
        ok(f'Feature token: {token}', token.lower() in h.lower())
# build toolchain diagnostic
ok('Gradle executable available', shutil.which('gradle') is not None, 'Install Gradle or use Android Studio/Gradle wrapper.')
ok('ANDROID_HOME/SDK available', bool(__import__('os').environ.get('ANDROID_HOME') or __import__('os').environ.get('ANDROID_SDK_ROOT')), 'Android SDK required for APK/AAB compilation.')
print('TaskMaster Pro Max v16 release audit')
passed=sum(x[1] for x in checks)
for n,c,d in checks: print(('PASS' if c else 'BLOCK'), '-', n, (f'({d})' if d and not c else ''))
print(f'STATIC RESULT: {passed}/{len(checks)} checks passed')
print('BUILD STATUS: NOT COMPILED in this environment' if passed else 'BUILD STATUS: blocked')
sys.exit(0)

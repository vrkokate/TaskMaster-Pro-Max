#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]; mf=ROOT/'RELEASE_SOURCE_MANIFEST.json'
data=json.loads(mf.read_text(encoding='utf-8')); fails=[]
for item in data['files']:
 p=ROOT/item['path']
 if not p.exists(): fails.append('MISSING '+item['path']); continue
 got=hashlib.sha256(p.read_bytes()).hexdigest()
 if got!=item['sha256']: fails.append('CHANGED '+item['path'])
print(f"PASS - source manifest verified: {len(data['files'])} files")
if fails:
 print('\n'.join(fails)); sys.exit(1)

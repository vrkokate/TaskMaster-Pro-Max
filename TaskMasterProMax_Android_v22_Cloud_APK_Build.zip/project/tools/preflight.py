from pathlib import Path
import re, sys, zipfile
root=Path(__file__).resolve().parents[1]
checks=[]
def ok(name, cond): checks.append((name,bool(cond)))
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
main=(root/'app/src/main/java/com/taskmaster/promax/MainActivity.java').read_text()
ok('HTML present', len(html)>10000)
ok('Room database', 'ReminderDatabase' in main)
ok('Task CRUD bridge', all(x in main for x in ['saveTask','completeTask','rescheduleTask','deleteTaskNative']))
ok('Recurring bridge', all(x in main for x in ['saveRecurringTask','setRecurringEnabled','deleteRecurringTask']))
ok('Reminder bridge', all(x in main for x in ['scheduleReminder','cancelReminder']))
ok('Deep-link', 'openTaskFromReminder' in html and 'openTaskFromReminder' in main)
ok('Notification permission', 'POST_NOTIFICATIONS' in manifest)
ok('Boot receiver', 'BOOT_COMPLETED' in manifest)
ok('Exact alarm permission', 'SCHEDULE_EXACT_ALARM' in manifest)
ok('Release version 1.0.3/14', 'versionCode 14' in gradle and 'versionName "1.0.3"' in gradle)
ok('Backup rules', (root/'app/src/main/res/xml/backup_rules.xml').exists())
ok('Data extraction rules', (root/'app/src/main/res/xml/data_extraction_rules.xml').exists())
ok('Safe migration/no destructive fallback', 'fallbackToDestructiveMigration' not in main)
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL')+' - '+n)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)

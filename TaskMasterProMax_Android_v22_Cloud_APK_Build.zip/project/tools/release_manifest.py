#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parents[1]
files=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and '.git' not in p.parts and 'build' not in p.parts:
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        files.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'bytes':p.stat().st_size})
out=ROOT/'RELEASE_SOURCE_MANIFEST.json'
out.write_text(json.dumps({'app':'TaskMaster Pro Max','version':'1.0.7','versionCode':18,'files':files},indent=2),encoding='utf-8')
print(f'WROTE {out} ({len(files)} files)')

#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle command not found. Open the project in Android Studio or add Gradle wrapper first." >&2
  exit 2
fi
gradle :app:assembleRelease :app:bundleRelease

from pathlib import Path
import re, sys
root=Path(__file__).parent
checks=[]
def ok(name, cond): checks.append((name,bool(cond)))
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
main=(root/'app/src/main/java/com/taskmaster/promax/MainActivity.java').read_text()
room=(root/'app/src/main/java/com/taskmaster/promax/ReminderDatabase.java').read_text()
boot=(root/'app/src/main/java/com/taskmaster/promax/BootReceiver.java').read_text()
receiver=(root/'app/src/main/java/com/taskmaster/promax/ReminderReceiver.java').read_text()
# Core presence
ok('HTML present', len(html)>10000)
ok('Native JS bridge', 'addJavascriptInterface' in main)
ok('Reminder scheduling/cancel bridge', 'scheduleReminder' in main and 'cancelReminder' in main)
ok('Task CRUD bridge', all(x in main for x in ['saveTask','completeTask','rescheduleTask','deleteTaskNative']))
ok('Recurring bridge', all(x in main for x in ['saveRecurringTask','setRecurringEnabled','deleteRecurringTask']))
ok('Dashboard sync bridge', 'getDashboardStatsJson' in main and 'getNativeTasksJson' in main)
ok('Reminder deep-link', 'openTaskFromReminder' in html and 'openTaskFromReminder' in main)
ok('Room migration 3→4', 'MIGRATION_3_4' in room and 'version=4' in room or 'version=4,' in room)
ok('No destructive migration', 'fallbackToDestructiveMigration' not in main and 'fallbackToDestructiveMigration' not in room and 'fallbackToDestructiveMigration' not in boot and 'fallbackToDestructiveMigration' not in receiver)
ok('Manifest notifications', 'POST_NOTIFICATIONS' in manifest and 'VIBRATE' in manifest)
ok('Manifest boot restore', 'BOOT_COMPLETED' in manifest and 'BootReceiver' in manifest)
ok('Exact alarm permission', 'SCHEDULE_EXACT_ALARM' in manifest)
ok('Release version', 'versionCode 20' in gradle and 'versionName "1.0.9"' in gradle)
ok('Backup rules', (root/'app/src/main/res/xml/backup_rules.xml').exists() and (root/'app/src/main/res/xml/data_extraction_rules.xml').exists())
ok('CI workflow', (root/'.github/workflows/android-release.yml').exists() and 'assembleRelease' in (root/'.github/workflows/android-release.yml').read_text())
ok('Release tools', all((root/f).exists() for f in ['tools/preflight.py','tools/release_manifest.py','tools/verify_release_source.py','tools/final_release_audit.py']))
# Basic Java brace balance (ignores strings imperfectly; catches structural truncation)
for f in root.glob('app/src/main/java/**/*.java'):
    txt=f.read_text(encoding='utf-8'); ok(f'Java braces: {f.name}', txt.count('{')==txt.count('}'))
# HTML structural sanity
ok('HTML closing tags', html.lower().count('</html>')==1 and html.lower().count('<html')==1)
failed=[n for n,v in checks if not v]
print(f'TaskMaster Pro Max v1.0.9 (20) Final Build Gate')
for n,v in checks: print(('PASS' if v else 'FAIL')+' - '+n)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)

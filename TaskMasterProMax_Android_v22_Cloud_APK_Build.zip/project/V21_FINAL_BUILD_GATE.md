# TaskMaster Pro Max v21 — Final Build Gate

Version: 1.1.0 (code 21)

## Source gate
- v20 final gate: 29/29 PASS
- Version alignment updated to 1.1.0 / 21
- No feature/UI source changes intended.

## Build gate
The repository includes CI automation for APK/AAB. A local build requires Android SDK and Gradle/Gradle Wrapper.
This ChatGPT build environment has neither `gradle` nor `ANDROID_HOME`, so no binary is claimed as compiled here.

## Required external verification
1. Open project in Android Studio.
2. Sync Gradle.
3. Build `assembleRelease` and `bundleRelease`.
4. Install APK on a real Android device.
5. Verify task CRUD, reschedule/history, recurring tasks, reminders, notification deep-link, reboot restore, backup/restore, calendar, search/filter and reports.
6. Record APK/AAB SHA-256.

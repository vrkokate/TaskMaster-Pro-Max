# TaskMaster Pro Max v16 — Final Integration QA

## Purpose
Final source-level hardening after v15. This release corrects Room index/schema parity so the v3→v4 migration matches the @Entity declarations exactly.

## Checks
- Version: 1.0.5 / code 16
- Room database version: 4
- MIGRATION_3_4 retained and non-destructive
- Task indexes: dueAt, status
- Task history index: taskId + at
- Reminder index: triggerAt
- Recurring index: enabled + firstDueAt
- Existing UI/features preserved

## Build status
APK/AAB compilation still requires Android SDK + Gradle/Android Studio. No APK is claimed from this environment.
